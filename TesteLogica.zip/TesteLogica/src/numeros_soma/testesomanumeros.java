package numeros_soma;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class testesomanumeros {

private static Scanner scanner;
	
	public static void main(String[] args) {
		
		Integer num = 0;
		ArrayList<Integer> sequencia = new ArrayList<>();
		
		System.out.println("Digite um n�mero inteiro e aperte enter ou '9999' para parar: ");
		
		//Preenche o conjunto de inteiros
		do{
			scanner = new Scanner(System.in);
			
			try {
				num = scanner.nextInt();
				
				if(num != 9999)
					sequencia.add(num);
	
			} catch (InputMismatchException e) {
				scanner.nextLine();
				System.out.println("Digite apenas n�meros Inteiros!!");
			}			
			
			if(num == 9999  && sequencia.isEmpty()) {
				System.out.println("N�o pode sair com o conjunto vazio!!");
				num = 0;
			}
			
		}while(num != 9999);
				
		System.out.println(subconjuntoSomaMaxima(sequencia));

	}

	private static ArrayList<String> subconjuntoSomaMaxima(ArrayList<Integer> s) {
	/**M�todo que recebe o conjunto de n�meros e retorna o subconjunto identificado por '**'
	 * @param s - ArrayList<Integer> (Conjunto de inteiros)
	 * @return sub - ArrayList<String> (Resultado com a identifica��o do subconjunto)
	 */
		
		ArrayList<String> sub = new ArrayList<>();
		int maxTotal, maxAtual, indX, indI, indF;
		maxAtual = 0;
		maxTotal = -1;
		indX = 0;
		indI = 0;
		indF = 0;	
		
		for(int i = 0; i < s.size(); i++) {
			maxAtual = maxAtual + s.get(i);
			
			//Se o resultado da soma for menor que a posi��o atual, atualiza o �ndice do subconjunto
			if(s.get(i) > maxAtual) {
				maxAtual = s.get(i);
				indX = i;			
			}				
			
			//Atualiza a soma total e seus �ndices no array
			if(maxAtual > maxTotal) {
				maxTotal = maxAtual;
				indI = indX;
				indF = i;
			}
			sub.add(s.get(i).toString());
		}		
		
		//Edita a posi��o inicial e final do subconjunto dentro do array
		sub.set(indI, "**" + s.get(indI).toString());
		sub.set(indF, s.get(indF).toString() + "**");
		
		return sub;
	}

}
